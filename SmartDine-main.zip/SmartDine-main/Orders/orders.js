var chickenPrice = 200;
var chickenQuantity = 1;
var totalPriceChicken = chickenQuantity * chickenPrice;
document.getElementById("Chicken-65-Price").textContent = totalPriceChicken;
document.getElementById("Chicken-65-Quantity").textContent = chickenQuantity;
